Tyler Kugler
CMPU-331: Compilers
Lexical Analyzer
Due Friday, September 21, 2018 (+1 slip day)

This Lexical Analyzer is designed to isolate tokens from an input file written in the language Vascal (a sublanguage of Pascal). It is designed to be run from an IDE like IntelliJ, and sample input files are stored in the Compiler project folder.

The Lexical Analyzer will choose one of the sample files if none is chosen by the user. The main method creates the Lexer and the Driver (which starts the Lexer’s analysis and keeps track of what it returns). This Lexical Analyzer complies with all of the lexical conventions. It also implements rudimentary error-handling; when a LEX ERROR is thrown, it will print out the line number and the sequence of characters that produced the error, and then attempt to move on and tokenize the rest of the file. 

 
