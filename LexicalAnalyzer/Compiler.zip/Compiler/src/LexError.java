public class LexError extends CompilerError {

    public LexError() {
    }

    public LexError(String message) {
        super(message);
    }

    public LexError(Throwable cause) {
        super(cause);
    }

    public LexError(String message, Throwable cause) {
        super(message, cause);
    }

}
