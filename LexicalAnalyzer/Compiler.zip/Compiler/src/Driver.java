import java.util.ArrayList;
import java.util.List;

public class Driver {

    // This class starts the Lexical Analyzer. It calls getNextToken() until there are no tokens left,
    // printing them out along the way.

    List<Token> tokenList;
    Lexer lexer;

    public Driver(Lexer lexer) {
        this.lexer = lexer;
        tokenList = new ArrayList<Token>();
    }

    public void start() {
        lexer.openFile(lexer.getFile());
        Token lastToken = new Token(Token.Type.PROGRAM, "Placeholder");
        while (lastToken.getType() != Token.Type.ENDOFFILE) {
            try {
                lastToken = lexer.getNextToken();
                lexer.setLastToken(lastToken);
                tokenList.add(lastToken);
                System.out.println("[" + lastToken.getType() + ", " + lastToken.getValue() + "]");


            }
            catch (LexError e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
