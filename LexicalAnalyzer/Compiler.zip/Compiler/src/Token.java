public class Token {

    // Tokens have a TYPE (enum) and a VALUE (String).

    public enum Type {
        PROGRAM, BEGIN, END, VAR, FUNCTION, PROCEDURE, RESULT, INTEGER, REAL, ARRAY,
        OF, IDENTIFIER, IF, THEN, ELSE, WHILE, DO, NOT, INTCONSTANT, REALCONSTANT,
        RELOP, MULOP, ADDOP, ASSIGNOP, COMMA, SEMICOLON, COLON, LEFTPAREN, RIGHTPAREN,
        DOUBLEDOT, LEFTBRACKET, RIGHTBRACKET, UNARYMINUS, UNARYPLUS, ENDMARKER, ENDOFFILE
    }

    public Type type;
    public String value;

    public Token(Type type, String value) {
        this.type = type;
        this.value = value;
    }

    public Type getType() {
        return type;
    }

    public String getValue() {
        return value;
    }
}