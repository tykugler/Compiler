
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Stack;

public class Lexer {

    private static final String VALID_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890"
            + ".,;:<>/*[]+-=()}{\t ";
    private static final String LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    private static final String DIGITS = "0123456789";
    private static final String ALLPUNCTUATION = ".,;:<>/*[]+-=()}{";
    private static final String PUNCTUATION = ".,;:<>/*[]+-=()"; // removed {}
    private static final int MAX = 64;

    String file;
    Stack<Character> stream;
    int currentIndex;
    int lineNumber;
    Token lastTokenReturned;

    public enum Keyword {
        PROGRAM, BEGIN, END, VAR, FUNCTION, PROCEDURE, RESULT, INTEGER, REAL, ARRAY,
        OF, IF, THEN, ELSE, WHILE, DO, NOT
    }

    public enum MathKeywords {
        DIV, MOD, AND, OR
    }

    public enum IdentifierOrEval {
        RIGHTPAREN, RIGHTBRACKET, IDENTIFIER, INTCONSTANT, REALCONSTANT
    }

    public Lexer(String file) {
        this.file = file;
        lineNumber = 1;
        currentIndex = 0;
        stream = new Stack<>();
        lastTokenReturned = null;
    }

    // getNextToken() analyzes the current character on the stream stack and
    // calls the appropriate method in order to return the correct token for
    // any given situation.
    public Token getNextToken() throws LexError {
        char currentChar = getNextChar();
        while (currentChar == ' ' || currentChar == '\n' || currentChar == '\t') {
            if (currentChar == '\n') {
                lineNumber++;
            }
            currentChar = getNextChar();
        }
        String currentToken = "" + currentChar;

        if (currentChar == '|') {
            return new Token(Token.Type.ENDOFFILE, null);
        }

        else if (!VALID_CHARS.contains(""+currentChar)) {
            throw new LexError("LEXER ERROR: Invalid character on line " + lineNumber + ": " + currentChar);
        }

        else if (LETTERS.contains(currentToken)) {
            return readIdentifier(currentToken);
        }

        else if (DIGITS.contains(currentToken)) {
            return readNumber(currentToken, false, false, true);
        }

        else if (currentChar == '}') {
            throw new LexError("LEXER ERROR: Ill-formed comment on line " + lineNumber + ", '}' not preceded by corresponding '{'.");
        }

        else if (currentChar == '{') {
            // '{' signifies a comment. It can only be completed by a '}'
            // If the EOF token is returned, return an EOF token.
            while (currentChar != '}') {
                if (currentChar == '|') {
                    throw new LexError("LEXER ERROR: End of file reached before closing '}': " + currentChar);
                }
                currentChar = getNextChar();
            }
            return this.getNextToken();
        }

        else if (PUNCTUATION.contains(currentToken)) {
            return readSymbol(currentChar);
        }

        throw new LexError("LEXER ERROR: Character unaccounted for in line " + lineNumber + ": " + currentChar);
    }

    // A symbol has been scanned. Process it accordingly.
    private Token readSymbol(char currentChar) throws LexError {
        char nextChar;
        switch(currentChar) {
            case '.':
                nextChar = getNextChar();
                if (nextChar == '.') {
                    return new Token(Token.Type.DOUBLEDOT, null);
                }
                stream.push(nextChar);
                return new Token(Token.Type.ENDMARKER, null);
            case ':':
                nextChar = getNextChar();
                if (nextChar == '=') {
                    return new Token(Token.Type.ASSIGNOP, null);
                }
                else {
                    stream.push(nextChar);
                    return new Token(Token.Type.COLON, null);
                }
            case ',':
                return new Token(Token.Type.COMMA, null);
            case '[':
                return new Token(Token.Type.LEFTBRACKET, null);
            case ']':
                return new Token(Token.Type.RIGHTBRACKET, null);
            case '(':
                return new Token(Token.Type.LEFTPAREN, null);
            case ')':
                return new Token(Token.Type.RIGHTPAREN, null);
            case ';':
                return new Token(Token.Type.SEMICOLON, null);
            case '<':
                nextChar = getNextChar();
                if (nextChar == '>') {
                    return new Token(Token.Type.RELOP, "2");
                }
                else if (nextChar == '=') {
                    return new Token(Token.Type.RELOP, "5");
                }
                else {
                    stream.push(nextChar);
                    return new Token(Token.Type.RELOP, "3");
                }
            case '>':
                nextChar = getNextChar();
                if (nextChar == '=') {
                    return new Token(Token.Type.RELOP, "6");
                }
                else {
                    stream.push(nextChar);
                    return new Token(Token.Type.RELOP, "4");
                }
            case '=':
                return new Token(Token.Type.RELOP, "1");
            case '*':
                return new Token(Token.Type.MULOP, "1");
            case '/':
                return new Token(Token.Type.MULOP, "2");
            case '+':
                Token lastToken = getLastToken();
                if (isIdentOrEval(lastToken)) {
                    return new Token(Token.Type.ADDOP, "1");
                }
                readUntilSignificantCharacter();
                nextChar = getNextChar();
                if (DIGITS.contains("" + nextChar)) {
                    String currentToken = "" + currentChar + nextChar;
                    try {
                        return readNumber(currentToken, false, false, true);
                    }
                    catch (LexError e) {
                        throw new LexError(e.getMessage());
                    }
                }
                stream.push(nextChar);
                return new Token(Token.Type.UNARYPLUS, null);
            case '-':
                if (isIdentOrEval(getLastToken())) {
                    return new Token(Token.Type.ADDOP, "2");
                }
                readUntilSignificantCharacter();
                nextChar = getNextChar();
                if (DIGITS.contains("" + nextChar)) {
                    String currentToken = "" + currentChar + nextChar;
                    try {
                        return readNumber(currentToken, false, false, true);
                    }
                    catch (LexError e) {
                        throw new LexError(e.getMessage());
                    }
                }
                stream.push(nextChar);
                return new Token(Token.Type.UNARYMINUS, null);
        }
        throw new LexError("LEXER ERROR: Symbol unaccounted for on line " + lineNumber + ": " + currentChar);
    }

    // (+ | - | epsilon)digit*( . digit* | epsilon)(E(+ | − | epsilon)digit*) | epsilon) is the form for all numbers
    // Numbers are constructed recursively.
    private Token readNumber(String currentToken, boolean hasDecimal, boolean hasExponent, boolean isInteger) throws LexError {

        // hasDecimal stores whether a decimal has been encountered.
        // hasExponent stores whether an exponent has been encountered.
        // isInteger stores whether the number can still be considered an INTCONSTANT.

        char nextChar = getNextChar();

        if (DIGITS.contains("" + nextChar)) {
            // Business as usual
            currentToken += nextChar;
            return readNumber(currentToken, hasDecimal, hasExponent, isInteger);
        }
        else if (nextChar == 'E' || nextChar == 'e') {
            if(hasExponent) {
                // Number of form 123E456E. Return error.
                throw new LexError("LEXER ERROR: Ill-formed constant on line " + lineNumber +": " + currentToken + nextChar);
            }
            else {
                currentToken += nextChar;
                return readNumber(currentToken, hasDecimal, true, false);
            }
        }
        else if (nextChar == '.') {
            if(!hasExponent) {
                if (hasDecimal && currentToken.charAt(currentToken.length() - 1) == '.') {
                    // DOUBLEDOT
                    currentToken = currentToken.substring(0, currentToken.length() - 1);
                    stream.push('.');
                    stream.push('.');
                    return new Token(Token.Type.INTCONSTANT, currentToken);
                } else if (hasDecimal) {
                    // number of form 123.456. Return error.
                    throw new LexError("LEXER ERROR: Ill-formed constant on line " + lineNumber +": " + currentToken + nextChar);
                } else {
                    currentToken += nextChar;
                    return readNumber(currentToken, true, false, false);
                }
            }
            else {
                // Number of form 34E56. Return error.
                throw new LexError("LEXER ERROR: Ill-formed constant on line " + lineNumber +": " + currentToken + nextChar);
            }
        }
        else if (nextChar == '+' || nextChar == '-') {
            char lastChar = currentToken.charAt(currentToken.length() - 1);
            if (lastChar == 'E' || lastChar == 'e') {
                currentToken += nextChar;
                return readNumber(currentToken, hasDecimal, hasExponent, false);
            }
            else if (lastChar == '.') {
                // return Error. Form is 1234.+
                throw new LexError("LEXER ERROR: Ill-formed constant on line " + lineNumber +": " + currentToken + nextChar);
            }
            else {
                // form is 123+_____ so return number token and push + back
                stream.push(nextChar);
                if (isInteger) {
                    return new Token(Token.Type.INTCONSTANT, currentToken);
                }
                else {
                    return new Token(Token.Type.REALCONSTANT, currentToken);
                }
            }
         }
        else if (nextChar == ' ' || ALLPUNCTUATION.contains("" + nextChar) || nextChar == '\n') {
            // Check if last char was '.' or 'E'
            char lastChar = currentToken.charAt(currentToken.length() - 1);
            String badEndings = "Ee.+-";
            stream.push(nextChar);

            if (badEndings.contains("" + lastChar)) {
                // throw Error. Form is 123. or 123E
                throw new LexError("LEXER ERROR: Ill-formed constant on line " + lineNumber +": " + currentToken + nextChar);
            }
            else {
                if (isInteger) {
                    return new Token(Token.Type.INTCONSTANT, currentToken);
                }
                else {
                    return new Token(Token.Type.REALCONSTANT, currentToken);
                }
             }
        }
        else {
            throw new LexError("LEXER ERROR: Ill-formed constant on line " + lineNumber +": " + currentToken + nextChar);
        }
    }

    // The character scanned was a letter, so read for an identifier and
    // try to match it to a keyword at the end.
    private Token readIdentifier(String id) throws LexError {
        // Keep reading characters so long as they are LETTERS or DIGITS.
        // As soon as a non-letter, non-digit character is found, return the string
        // and push the new character back onto the stack.
        char nextChar = getNextChar();
        while (LETTERS.contains("" + nextChar) || DIGITS.contains("" + nextChar)) {
            id += nextChar;
            nextChar = stream.pop();
        }
        stream.push(nextChar);

        if (id.length() > MAX) {
            throw new LexError("LEXER ERROR: Identifier too long on line " + lineNumber + ": " + id);
        }

        String capID = id.toUpperCase();

        if (isKeyword(capID)) {
            return new Token(Token.Type.valueOf(capID), null);
        }
        if (isMathKeyword(capID)) {
            return getMathKeywordToken(capID);
        }
        return new Token(Token.Type.IDENTIFIER, capID);
    }

    // Gets the next character.
    private char getNextChar() {
        if (stream.empty()) {
            return '|';
        }
        return stream.pop();
    }

    // Only used by '+' and '-' to find the next significant character
    // in order to decide between CONSTANT/UNARY
    private void readUntilSignificantCharacter() {
        char nextChar = getNextChar();
        while (nextChar == ' ' || nextChar == '\n') {
            if (nextChar == '\n') {
                lineNumber++;
            }
            nextChar = getNextChar();
        }
        stream.push(nextChar);
    }

    // Determines if a string is a non-math keyword
    public static boolean isKeyword(String test) {
        for (Keyword keyword : Keyword.values()) {
            if (keyword.name().equals(test)) {
                return true;
            }
        }
        return false;
    }

    // Determines if a string is a math keyword
    private boolean isMathKeyword(String capID) {
        for (MathKeywords keyword : MathKeywords.values()) {
            if (keyword.name().equals(capID)) {
                return true;
            }
        }
        return false;
    }

    // Returns a token of type matching the math keyword
    private Token getMathKeywordToken(String capID) {
        switch(capID) {
            case "MOD":
                return new Token(Token.Type.MULOP, "4");

            case "DIV":
                return new Token(Token.Type.MULOP, "3");

            case "AND":
                return new Token(Token.Type.MULOP, "5");

            case "OR":
                return new Token(Token.Type.ADDOP, "3");

            }
        return new Token(Token.Type.BEGIN, "E R R O R.");
    }

    // Determines whether a token is RIGHTPAREN, RIGHTBRACKET, IDENTIFIER, REALCONSTANT, or INTCONSTANT
    private boolean isIdentOrEval(Token token) {
        for (IdentifierOrEval type : IdentifierOrEval.values()) {
            if (type.name().equals(token.getType().toString())) {
                return true;
            }
        }
        return false;
    }

    private Token getLastToken() {
        return this.lastTokenReturned;
    }

    public void setLastToken(Token token) {
        this.lastTokenReturned = token;
    }

    public String getFile() {
        return this.file;
    }

    public void openFile(String file) {
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            Stack<Character> loadStream = new Stack<>();
            while ((line = br.readLine()) != null) {
                for (int i = 0; i < line.length(); i++) {
                    loadStream.push(line.charAt(i));
                }
                loadStream.push('\n'); // End of line character
            }
            int stackSize = loadStream.size();
            for (int j = 0; j < stackSize; j++) {
                stream.push(loadStream.pop());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // The main method checks whether the user has given it a file to read.
    // If so, it will complete Lexical Analysis on that file.
    // Otherwise, it will call the Lexical Analyzer on a sample file.
    public static void main(String[] args) {
        String file;
        if (args.length == 0) {
            System.out.println("This is a Lexical Analyzer. Give it a text file written in Vascal and " +
                    "it will return the tokens associated with that code.");
            file = "sample3input.txt";
        }
        else {
            file = args[0];
        }
        Lexer lexer = new Lexer(file);
        Driver driver = new Driver(lexer);
        driver.start();
    }
}
